
<div class="row">

    <div class="col-lg-1 col-centered">
	<a href="<?php echo base_url();?>signup/candidate">
	<button class="btn btn-primary">Candidate Signup</button>
	</a>
	<br/><br/>
	<a href="<?php echo base_url();?>signup/volunteer">
	<button class="btn btn-default">Volunteer Signup</button>
	</a>
	</div>
</div>
