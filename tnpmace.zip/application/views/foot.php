<!--<p>{elapsed_time}s</p>-->

<div class="container-fluid" id="foot_hold" style="position:relative;">
<hr>
	<div style="position:absolute; bottom:5px; left:0px; width:100%">  <div style="color:#a3a3a3; text-align:center;">Training and Placement Cell <br/>Mar Athanasius College of Engineering, Kothamangalam</div> </div>
</div>

</body>
<script type="text/javascript">
	$(document).ready(function(){
		$('#excel_hidden').val( $('#excel_inside').html() );
		$('#excel_submit').prop('disabled',false);
	});
	</script>
</html>
