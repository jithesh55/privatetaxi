<!doctype html>
<html>
<head>
	<title>Ticket taking machine</title>
</head>

<body>


<form method="post" action="">
	Select Starting point: 
	<select name="source">
		<option value="1">Kothamangalam</option>
		<option value="2">Kozhipilly</option>
		<option value="3">Adivad</option>
		<option value="4">Pothanicad</option>
	</select>
	Select Desctination point: 
	<select name="dest">
		<option value="1">Kothamangalam</option>
		<option value="2">Kozhipilly</option>
		<option value="3">Adivad</option>
		<option value="4">Pothanicad</option>
	</select>
	<input type="submit" value="Get ticket">
</form>

</body>
</html>